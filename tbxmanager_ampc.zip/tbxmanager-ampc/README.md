# Toolbox Manager

Toolbox Manager is a package manager for Matlab. In short, it's to Matlab what `apt-get` is to Linux.

This repository contains the Matlab command-line client that allows to install and update toolboxes. The central repository of available packages is hosted at [www.tbxmanager.com](http://www.tbxmanager.com).

This version is a fork of [github.com/kvasnica/tbxmanager](https://github.com/kvasnica/tbxmanager) and was adapted to support CasADi.

## Installation:
Navigate to your tbxmanager_ampc installation path in MATLAB and run.

```matlab
tbxmanager_ampc
savepath
```

Edit/create `startup.m` in your Matlab startup folder (on Windows this is by default Documents/MATLAB) and put the following line there:

```
tbxmanager_ampc restorepath
```

Alternatively, run this command manually every time you start Matlab.

## Installation of packages

```
tbxmanager_ampc install package_name
```

To install all required Advanced MPC packages run

```
tbxmanager_ampc install mpt mptdoc cddmex fourier glpkmex hysdel lcp yalmip sedumi espresso casadi
```


## List available packages

```
tbxmanager_ampc show available
```

## All supported commands

```
tbxmanager_ampc install package1 package2 ...
tbxmanager_ampc show enabled
tbxmanager_ampc show installed
tbxmanager_ampc show available
tbxmanager_ampc show sources
tbxmanager_ampc update
tbxmanager_ampc update package1 package2 ...
tbxmanager_ampc restorepath
tbxmanager_ampc generatepath
tbxmanager_ampc enable package1 package2 ...
tbxmanager_ampc disable package1 package2 ...
tbxmanager_ampc uninstall package1 package2 ...
tbxmanager_ampc require package1 package2 ...
```
